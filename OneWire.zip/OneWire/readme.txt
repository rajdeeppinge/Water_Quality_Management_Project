See:
    http://www.arduino.cc/playground/Learning/OneWire
    http://www.federated.com/~jim/onewire/

The version of the OneWire library at federated.com works with arduino-0007.
The version here works with arduino-0008, 1.0+ thanks to the very helpful Jim Studt.

To use, make a new directory: arduino-0008/lib/targets/libraries/OneWire/
and put OneWire.cpp, OneWire.h and keywords.txt in it.

--Josh Larios
hades (at) elsewhere (dot) org
2007/07/06